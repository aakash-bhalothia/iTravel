//
//  FoldingCellFramework.h
//  FoldingCellFramework
//
//  Created by Alex K. on 30/12/15.
//  Copyright © 2015 Alex K. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FoldingCellFramework.
FOUNDATION_EXPORT double FoldingCellFrameworkVersionNumber;

//! Project version string for FoldingCellFramework.
FOUNDATION_EXPORT const unsigned char FoldingCellFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FoldingCellFramework/PublicHeader.h>


