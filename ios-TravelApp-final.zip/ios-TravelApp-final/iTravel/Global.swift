//
//  Global.swift
//  iTravel
//
//  Created by Mudit on 4/21/17.
//  Copyright © 2017 Aakash Bhalothia. All rights reserved.
//

import Foundation
